<script setup>
import ProfileCard from './Components/ProfileCard.vue'
import './style.css'
</script>

<template>
  <div class="min-h-screen flex flex-wrap items-center justify-center gap-10 bg-gradient-to-r from-green-400 to-blue-500 p-10">
    
    <ProfileCard 
      background="https://pbs.twimg.com/profile_banners/2016808278374969344/1769679658/1080x360"
      profileimg="https://pbs.twimg.com/profile_images/2016808778763792384/HGwvqhfI_400x400.jpg"
      name="Atcharayu Tunyakan"
      subheading="Student, IT, SMSK"
      followers="0"
      following="0"
      projects="1"
      X="https://x.com/R_7wX"
      instagram="https://www.instagram.com/ay.tk.px/"
      facebook="https://www.facebook.com/ay.tk.370"
    />

    <ProfileCard 
      background="https://pbs.twimg.com/profile_banners/50393960/1745250848/1080x360"
      profileimg="https://pbs.twimg.com/profile_images/1879013694367252480/Gxa-Pspq_400x400.jpg"
      name="Bill Gates"
      subheading="Businessman, CS, USA"
      followers="62.3M"
      following="571"
      projects="50000"
      X="https://x.com/BillGates"
      instagram="https://www.instagram.com/thisisbillgates/?hl=en"
      facebook="https://www.facebook.com/BillGates/"
    />

    <ProfileCard 
      background="https://scontent-bkk1-1.xx.fbcdn.net/v/t39.30808-6/510262894_10116675748582961_3647797500193179162_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=101&ccb=1-7&_nc_sid=cc71e4&_nc_eui2=AeHRrJtMuMONJ51gU_W8XDuTRZ1Ht03DIg5FnUe3TcMiDvPWdCxT2P8h8De1Ftqy4EBkZI9or4Lag-Ht_T7DBmmf&_nc_ohc=KIO7dHoLEZEQ7kNvwE4BIXr&_nc_oc=Adl7DJsO8IcAEcazYA1sS-nNXKYxhbt2ztyKzdrgCv44kXrBMEna68nM1l4--3yRjlw&_nc_zt=23&_nc_ht=scontent-bkk1-1.xx&_nc_gid=Wiu4pTAYp1I3WV-gUBFZmQ&oh=00_Afq4A5NquHvF7Wd7EJDy4_eAApazch8tSMMT4JyJOM2iDw&oe=69811104"
      profileimg="https://pbs.twimg.com/profile_images/77846223/profile_400x400.jpg"
      name="Mark Zuckerberg"
      subheading="Bussinessman, CS, USA"
      followers="121M"
      following="709"
      projects="22000"
      X="https://x.com/finkd"
      instagram="https://www.instagram.com/zuck/?hl=en"
      facebook="https://www.facebook.com/zuck/"
    />

  </div>
</template>